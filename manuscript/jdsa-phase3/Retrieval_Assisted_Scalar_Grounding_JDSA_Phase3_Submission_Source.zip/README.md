# Flat JDSA Phase 3 source package (author review)

Extract into an empty directory. Install TeX Live with pdfLaTeX, BibTeX,
amsmath, graphicx, tabularx, booktabs, algorithm/algorithmicx/algpseudocode,
xurl, microtype, xr-hyper, hyperref, multirow and placeins, plus dependencies
of the supplied Springer Nature class. Run `sh build.sh`.

This independently builds the complete main article and Online Resource 1,
resolves cross-document citations, and produces descriptively named PDFs.
All manuscript inputs are inlined: the source upload has no subfolders.
The supplied vector Fig1.pdf is used directly. Fig1.tex is its editable
TikZ/standalone source; regenerating it is optional and document-only.
Keep both generated PDFs in the same directory for relative PDF links.
Some browser viewers do not follow cross-document PDF links.

Main article: main.tex; supplementary information: supplement.tex.
The journal requires an editable source package and a compiled PDF.
Online Resource 1 is the generated ESM_1_..._Supplement.pdf.
No missing historical experimental outputs can be recovered from this ZIP.
No dataset, private review log, local M5 evidence or credentials are included.

Original Springer class/style notices and third-party rights are retained.
No new license is assigned. Manuscript licensing, funding, metadata,
declarations and final approval require the author's review.
Do not submit until withdrawal of the previous overlapping submission is
confirmed. This package is not a journal submission or author approval.
